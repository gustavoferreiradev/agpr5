<div class="gallery_content_area_sidebar">
	<?php 
		echo do_shortcode('[project_details]');
	?>
</div>