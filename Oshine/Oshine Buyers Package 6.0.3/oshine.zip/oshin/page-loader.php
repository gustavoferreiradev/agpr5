<div class="loader page-loader">
	<?php
		global $be_themes_data;
		$loader_style = (isset($be_themes_data['page_loader_style']) && !empty($be_themes_data['page_loader_style'])) ? $be_themes_data['page_loader_style'] : 'style1-loader';
		if( $loader_style == 'style6-loader' ) {
			echo '<div class="loader-style6"></div>';
		} elseif( $loader_style == 'style5-loader' ) {
			echo '<div class="loader-style5-wrap"><div class="dot1"></div><div class="dot2"></div></div>';
		} elseif( $loader_style == 'style4-loader' ) {
			echo '<div class="loader-style4-wrap"></div>';
		} elseif( $loader_style == 'style3-loader' ) {
			echo '<div class="loader-style3-wrap"><div class="rect1"></div><div class="rect2"></div><div class="rect3"></div><div class="rect4"></div><div class="rect5"></div></div>';
		} elseif( $loader_style == 'style2-loader' ) {
			echo '<div class="loader-style2-wrap"></div>';
		} else {
			echo '<div class="loader-style1-wrap"><div class="loader-style1-double-bounce1"></div><div class="loader-style1-double-bounce2"></div></div>';
		}
	?>
</div>